﻿namespace UnitTesting.TestImplementation
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class MsTest
    {
        [ClassInitialize]
        public void ClassInit()
        {
        }

        [TestInitialize]
        public void TestInit()
        {
        } 
        
        [TestMethod, Ignore]
        public void SimpleTestExample()
        {
        }

        [TestMethod, Owner("Yauheni Tsesliuk")]
        public void SimpleTestOwner()
        {
        }

        [TestMethod, DeploymentItem("Test.xml")]
        public void SimpleTestDeploy()
        {
        }

        [TestMethod, Description("Just simple example")]
        public void SimpleTestDescription()
        {
        }

        [TestMethod, ExpectedException(typeof(System.FormatException))]
        public void SimpleTestError()
        {
        }

        [TestMethod, TestCategory("Regression")]
        public void SimpleTestCategoty()
        {
        }

        [TestMethod, Timeout(500)]
        public void SimpleTestTime()
        {
        }

        [TestCleanup]
        public void TestClean()
        {
        }
                
        [ClassCleanup]
        public void ClassClean()
        {
        }
    }
}
